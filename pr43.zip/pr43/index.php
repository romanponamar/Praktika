<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<title>Программирование на языке PHP</title>
</head>
<body>
	<h1>Функции</h1>
	<h2>Встроенные функции, часть 1</h2>
	
	<?php
		require "teams.php";

		$team = isset($_GET['team']) ? (int)$_GET['team'] -1 : 0;

if (array_key_exists($team, $content)) {

    echo "<h3>Информация о выбранной группе:</h3>";
    echo 'ID группы: ',$content[$team]['id'],"<br>";
	echo 'Группы: ',$content[$team]['name'],"<br>";
	echo 'Страна: ',$content[$team]['country'],"<br>";
	echo 'Дата основания: ',$content[$team]['date'],"<br>";
	echo 'Стиль: ',$content[$team]['style'],"<br>";
	
}

else {
    echo "<h3>Группа не найден</h3>";
}
	
	?>
	

</body>
</html>