<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php

    require 'albums.php';
    require 'tracks.php';

$album = isset($_GET['album']) ? (int)$_GET['album'] -1 : 0;
$track = isset($_GET['track']) ? (int)$_GET['track'] -1 : 0;

if (array_key_exists($album, $albums)) {

    echo "<h3>Информация о выбранном альбоме:</h3>";
    echo 'ID альбома: ',$albums[$album]['id_album'],"<br>";
    echo 'Название: ',$albums[$album]['title'],"<br>";
    echo 'Дата выпуска: ',$albums[$album]['date'],"<br>";
    echo 'Срана выпуска: ',$albums[$album]['country'],"<br>";
    echo 'ID команды: ',$albums[$album]['id_team'],"<br>";
}

else {
    echo "<h3>Альбом не найден</h3>";
}

if (array_key_exists($track, $tracks)) {

    echo "<h3>Информация о выбранном треке:</h3>";
    echo 'ID трека: ',$tracks[$track]['id_track'],"<br>";
    echo 'Название трека: ',$tracks[$track]['name'],"<br>";
    echo 'ID альбома: ',$tracks[$track]['id_album'],"<br>";
}

else {
    echo "<h3>Трек не найден</h3>";
}

    ?>
</body>
</html>